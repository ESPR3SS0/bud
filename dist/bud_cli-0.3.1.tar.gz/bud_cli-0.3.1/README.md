<div align="center">

**For updates, questions and more:**    

</a>
</div>

<h1 align="center"> Bud - A buddy to help you with projects</h1>

<h4 align="center"> This is a very early project I making to help me out with project organization and goal making. I am very quick to think of awesome cool project ideas, but also very quick to abondon said awesome things for a new project. This tool helps me make goals and hit them. </h4>

- Planned additions:
    - [ ] Optional indepth description per task
    - [ ] Command to Move multiple tasks at once
    - [ ] Optional Target Date 
    - [ ] A project specific config 
    - [ ] UI to present Local 'TODO's 

Looking way down the road to some things I think would be nice:
    Proj management 
    - [ ] Gant Chart
    - [ ] Mile stones 
    - [ ] Completion graph 
    - [ ] Various stats about the project
        - [ ] Commit graphs
        - [ ] Mile stones met
        - [ ] Fun stats (code length, dir length)

Tools that are potentially useful for showing non-terminal savy others:
    - [ ] Output progress to excel 
    - [ ] Output milestones
    - [ ] Pretty much any general output to excel


    
# ♥ Credits

- This was inspired by other task managing CLI tools such as:
    - please-cli 
    - taskwarrior
